#------------------------------------------------------------------------------------------


import streamlit as st
import numpy as np
import pickle
import time  
# PERSONNALISATION DU DESIGN (COULEUR DE FOND) 
st.markdown(
    """
    <style>
    /* 1. Fond sombre  */
    .stApp {
        background-color: #1E1E1E; 
    }

    /* 2. Texte en blanc */
    h1, h2, h3, p, span, div, label, .stMarkdown {
        color: #E0E0E0 !important;
    }

    /* 3. Bouton "Prédire"  */
    .stButton>button {
        background-color: #007BFF;
        color: white !important;
        border: none;
        border-radius: 8px;
        padding: 10px 20px;
        font-weight: bold;
    }

    /* 4. Les champs de saisie */
    input {
        background-color: #2D2D2D !important;
        color: white !important;
    }
    </style>
    """,
    unsafe_allow_html=True
)


# CONFIGURATION DE LA PAGE
st.set_page_config(page_title="IA Admission Étudiant", page_icon="👽")

# 1. Fonction Sigmoïde (Le cœur du modèle)
def sigmoid(z):
    return 1 / (1 + np.exp(-z))

# 2. Chargement du modèle (On récupère w et b du Dataset 1)
@st.cache_resource
def load_model():
    try:
        with open("model_etudiant.pkl", "rb") as f:
            return pickle.load(f)
    except FileNotFoundError:
        return None

data = load_model()

if data is None:
    st.error(" Fichier 'model_etudiant.pkl' introuvable ! Vérifie ton dossier.")
    st.stop()

w, b = data["w"], data["b"]

# INTERFACE UTILISATEUR
st.title("Assistant d'Admission Intelligent")
st.write("Évaluons les chances de réussite d'un candidat.")

# Organisation en deux colonnes
col1, col2 = st.columns(2)

with col1:
    st.markdown("### Notes obtenues")
    note1 = st.number_input("Note de l'examen n°1", min_value=0.0, max_value=100.0, value=0.0)
    note2 = st.number_input("Note de l'examen n°2", min_value=0.0, max_value=100.0, value=0.0)

with col2:
    st.markdown(" ###  Ce modèle de Régression Logistique analyse les scores pour prédire l'admission finale des élèves")

st.divider()

# ANALYSE ET RÉSULTATS 
if st.button(" Lancer la prédiction"):
    # Effet "L'IA réfléchit"
    with st.spinner("Analyse des probabilités en cours..."):
        time.sleep(2.5) # Petit délai pour l'effet visuel
        
        # Calcul mathématique
        x = np.array([note1, note2])
        z = np.dot(x, w) + b
        prob = float(sigmoid(z))
    
    # Affichage des résultats après le chargement
    st.subheader(f"Résultat de l'analyse : {prob*100:.1f}% de réussite")
    st.progress(prob) # Barre de progression visuelle
    
    if prob >= 0.4:
        st.snow() # Animation de fête
        st.success(f" **ADMIS** : Félicitations ! L'élève est admius.")
    else:
        st.error(f" **REFUSÉ** : Le candidat n'a pas la note réquise .")
        st.warning("Conseil : Une préparation supplémentaire est nécessaire pour les prochains examens.")

st.caption("Projet ML - Régression Logistique - © 2026 Interface Streamlit ")


